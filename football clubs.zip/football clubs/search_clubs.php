<h1>Search results</h1>
<?php

  // Connect to database and run SQL query
  include("db.php");

  // Read value from form
  $keywords = $_POST['keywords'];  

  // Run SQL query
  $sql = "SELECT * FROM football_clubs 
          WHERE game_name LIKE '%{$keywords}%' 
          ORDER BY football";
          
  $results = mysqli_query($mysqli, $sql);
?>

<table>
  <?php while($a_row = mysqli_fetch_assoc($results)):?>
    <tr>
      <td><a href="football-details.php?id=<?=$a_row['football_club']?>"><?=$a_row['football_description']?></a></td>
      
    </tr>
  <?php endwhile;?>
</table>
