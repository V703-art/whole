<?php
  
  // Read values from the form
  $football_game = $_POST['FootballName'];
  $gFootball_description = $_POST['FootballDescription'];
 
  // Connect to database
  include("db.php");
  
  // Build SQL statement
  $sql = "INSERT INTO videogames(game_name, game_description, released_date, rating)
          VALUE('{$football_name}', '{$football_description}',)";
  
  // Run SQL statement and report errors
  if(!$mysqli -> query($sql)) {
      echo("<h4>SQL error description: " . $mysqli -> error . "</h4>");
  }
  
  // Redirect to list
  header("location: list-games.php");
