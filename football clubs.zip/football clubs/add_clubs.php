<?php
include("db.php");

$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$desc = isset($_POST['description']) ? trim($_POST['description']) : '';
$date = isset($_POST['date']) ? trim($_POST['date']) : '';

if ($name && $date) {
    $stmt = $mysqli->prepare("INSERT INTO football_clubs (football_name, football_description, released_date) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $desc, $date);

    if ($stmt->execute()) {
        echo "✅ Club added successfully!";
    } else {
        echo "❌ Error adding club: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "⚠️ Please fill in all required fields.";
}

$mysqli->close();
?>
